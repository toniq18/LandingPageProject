# Landing Page Project

## Table of Contents


* [What went well](#WhatWentWell)
* [Difficulties](#Difficulties)
* [Resources Used](#ResourcesUsed)


## WhatWentWell

Utalising the mentor help to assist me through and difficulties entountered

## Difficulties

Knowing where to start the project was difficult for me, i had prior knowledge to java script but this more in depth then i had experiace with, alot of new content to learn

## ResourcesUsed

Udacity's free javaScript course, Mentor Help 
